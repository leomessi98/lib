package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dao.ProductDao;
import com.cg.model.Product;

@Controller
public class ProductController {

	@Autowired
	ProductDao productDao;
	
	@RequestMapping("/productform")
	public String showproductform(Model m) {
		Product p = new Product();
		m.addAttribute("command",p);
		return "productform";

	}

	@RequestMapping("/save")
	public String addProduct(@ModelAttribute("product") @Valid Product product,BindingResult bindingResult) {
		if(bindingResult.hasErrors()) {
			System.out.println("Details are not correct");
			return "productform";
		}
		productDao.save(product);
		return "redirect:/viewproduct";
	}
	
	@RequestMapping("/viewproduct")
	public String viewAllProduct(Model m) {
		List<Product> productlist= productDao.getAllproducts();
		m.addAttribute("plist", productlist);
		return "viewproduct";
		
	}
	
	@RequestMapping("/delete")
	public String delete(@RequestParam("pid") int pid) {
		productDao.delete(pid);
		return "redirect:/viewproduct";
	}
	
	@RequestMapping("/updateform")
	public String updateform(@RequestParam int pid, Model m) {
		Product product = productDao.getById(pid);
		m.addAttribute("command", product);
		return "updateform";
		
	}

	@RequestMapping("/update")
	public String updateProduct(@ModelAttribute("product") Product product) {
		productDao.update(product);
		return "redirect:/viewproduct";
	}
}
