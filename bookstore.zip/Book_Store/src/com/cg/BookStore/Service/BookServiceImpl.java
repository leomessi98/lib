package com.cg.BookStore.Service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.BookStore.Beans.Book;
import com.cg.BookStore.Dao.BookDao;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDao bookDao;

	@Transactional
	public void saveBook(Book book) {
		bookDao.saveBook(book);
	}

	@Transactional(readOnly = true)
	public List<Book> listBooks() {
		return bookDao.listBooks();
	}

	@Transactional(readOnly = true)
	public Book getBook(int id) {
		return bookDao.getBook(id);
	}

	@Transactional
	public void deleteBook(int id) {
		bookDao.deleteBook(id);

	}

	@Override
	@Transactional
	public void update(Book book) {
		bookDao.update(book);
		
	}

	

}
