package com.cg.BookStore.Controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;

import com.cg.BookStore.Beans.Book;
import com.cg.BookStore.Service.BookService;

@Controller
public class BookController {

	@Autowired
	BookService bookService;

	@RequestMapping("/index")
	public String start() {
		return "index";
	}

	@RequestMapping("/bookForm")
	public String showproductform(Model m) {
		Book book = new Book();
		m.addAttribute("book", book);
		return "bookForm";

	}

	@RequestMapping("/save")
	public String addProduct(@ModelAttribute("book") Book book) {
	
		bookService.saveBook(book);
		return "redirect:/viewBook";
	}

	@RequestMapping("/viewBook")
	public String viewAllProduct(Model m) {
		List<Book> booklist = bookService.listBooks();
		m.addAttribute("booklist", booklist);
		return "viewBook";

	}

	@RequestMapping("/delete")
	public String delete(@RequestParam("id") int id) {
		bookService.deleteBook(id);
		return "redirect:/viewBook";
	}

	@RequestMapping("/updateform")
	public String updateform(@RequestParam int id, Model m) {
		Book book = bookService.getBook(id);
		m.addAttribute("book", book);
		return "updateform";

	}

	@RequestMapping("/update")
	public String updateProduct(@ModelAttribute("book") Book book) {
		bookService.update(book);
		return "redirect:/viewBook";
	}

}
