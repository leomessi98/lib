package com.cg.BookStore.Beans;

import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Book_Details")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int serialNo;
	private int id;
	private String title;
    private String author;
	private String category;
	private float price;
	private Date lastUpdated;
	
	public Book() {
		// TODO Auto-generated constructor stub
	}
	
	public Book(int serialNo, int id, String title, String author, String category, float price, Date lastUpdated) {
		super();
		this.serialNo = serialNo;
		this.id = id;
		this.title = title;
		this.author = author;
		this.category = category;
		this.price = price;
		this.lastUpdated = lastUpdated;
	}

	public int getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	@Override
	public String toString() {
		return "Book [serialNo=" + serialNo + ", id=" + id + ", title=" + title + ", author=" + author + ", category="
				+ category + ", price=" + price + ", lastUpdated=" + lastUpdated + "]";
	}
	
	
	


}
