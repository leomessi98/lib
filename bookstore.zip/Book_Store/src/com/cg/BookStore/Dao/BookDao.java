package com.cg.BookStore.Dao;

import java.util.List;

import com.cg.BookStore.Beans.Book;

public interface BookDao {

	public boolean saveBook(Book book);

	public boolean update(Book book);

	public List<Book> listBooks();

	public Book getBook(int id);

	public boolean deleteBook(int id);
}
