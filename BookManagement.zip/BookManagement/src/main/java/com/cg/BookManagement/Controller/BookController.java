package com.cg.BookManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.BookManagement.Beans.Book;
import com.cg.BookManagement.Service.BookService;

@RestController
public class BookController {

	@Autowired
	private BookService bookService;

	/*
	 * @GetMapping("/manage/book") public ResponseEntity<List<Book>> list(){
	 * List<Book> list = bookService.list(); return ResponseEntity.ok().body(list);
	 * }
	 */

	@RequestMapping("/booklist")
	List<Book> viewBooks()

	{
		return bookService.list();

	}

	/*
	 * @PostMapping("/manage/create") public ModelAndView create(@RequestParam int
	 * ){ bookService.save(book); return }
	 */
	/*
	 * @GetMapping("/manage/create/{}") public Model create(@RequestParam Book book)
	 * { Model m = bookService.save(book); return m; }
	 */

	/*
	 * @PostMapping(value =
	 * "/create/{bookIndex}/{id}/{title}/{author}/{category}/{price}") public
	 * ResponseEntity create(@RequestBody Book book) {
	 * 
	 * bookService.save(book);
	 * 
	 * return new ResponseEntity(book, HttpStatus.OK); }
	 */
	
	
	@RequestMapping("/create/{bookIndex}/{id}/{title}/{author}/{category}/{price}")
	public Book create(Book book)
	{
	
		
	    bookService.save(book);
		return book;
	}

	@DeleteMapping("/books/{id}")
	public ResponseEntity deleteCustomer(@PathVariable int id) {
		bookService.delete(id);
		return new ResponseEntity(id, HttpStatus.OK);

	}

	@PutMapping("update/{id}")
	public ResponseEntity updateCustomer(@PathVariable int id, @RequestBody Book book) {

		bookService.update(id, book);

		return new ResponseEntity(book, HttpStatus.OK);
	}
}
