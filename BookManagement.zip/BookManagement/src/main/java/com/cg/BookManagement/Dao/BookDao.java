package com.cg.BookManagement.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.BookManagement.Beans.Book;


@Repository("bookDao")
public interface BookDao extends JpaRepository<Book, Integer> {

	
	}
