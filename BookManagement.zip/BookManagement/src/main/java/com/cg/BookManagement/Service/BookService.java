package com.cg.BookManagement.Service;

import java.util.List;


import com.cg.BookManagement.Beans.Book;



public interface BookService {

	void save(Book book);
	Book get(int id);
	List<Book> list();
	void update(int id,Book book);
	void delete(int id);
}
