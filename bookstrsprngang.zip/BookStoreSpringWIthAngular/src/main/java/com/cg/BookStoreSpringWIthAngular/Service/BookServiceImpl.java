package com.cg.BookStoreSpringWIthAngular.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.BookStoreSpringWIthAngular.Beans.Book;
import com.cg.BookStoreSpringWIthAngular.Dao.BookDao;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDao bookDao;

	@Transactional
	public void saveBook(Book book) {
		bookDao.save(book);
	}

	@Transactional(readOnly = true)
	public List<Book> listBooks() {
		return bookDao.findAll();
	}

	@Transactional(readOnly = true)
	public Book getBook(int id) {
		return bookDao.getOne(id);
	}

	@Transactional
	public void deleteBook(int id) {
		bookDao.deleteById(id);

	}

	@Override
	@Transactional
	public void update(Book book) {
		bookDao.save(book);

	}

}
