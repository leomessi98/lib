package com.cg.BookStoreSpringWIthAngular.Service;

import java.util.List;

import com.cg.BookStoreSpringWIthAngular.Beans.Book;



public interface BookService {

	/*
	 * CREATING AND UPDATING BOOT DATA
	 */
	public void saveBook(Book book);
    public void update(Book book);
	/*
	 * READING BOOK DATA
	 */  
	public List<Book> listBooks();
	public Book getBook(int id);

	/*
	 * DELETING BOOK
	 */
	public void deleteBook(int id);

}
