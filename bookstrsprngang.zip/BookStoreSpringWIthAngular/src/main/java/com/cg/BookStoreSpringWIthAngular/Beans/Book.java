package com.cg.BookStoreSpringWIthAngular.Beans;

import java.awt.Image;
import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Book_Details")
public class Book {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "slNo")
	private int bookIndex;
	private int id;
	//private Image image;
	private String title;
    private String author;
	private String category;
	private float price;
	@Column(name = "lastUpdated")
	private Time lastUpdated;
	
	public Book() {
		// TODO Auto-generated constructor stub
	}

	public Book(int bookIndex, int id, Image image, String title, String author, String category, float price,
			Time lastUpdated) {
		super();
		this.bookIndex = bookIndex;
		this.id = id;
		//this.image = image;
		this.title = title;
		this.author = author;
		this.category = category;
		this.price = price;
		this.lastUpdated = lastUpdated;
	}

	public int getBookIndex() {
		return bookIndex;
	}

	public void setBookIndex(int bookIndex) {
		this.bookIndex = bookIndex;
	}

	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		 this.id = id;
	}
	

	

	/*
	 * public Image getImage() { return image; }
	 * 
	 * public void setImage(Image image) { this.image = image; }
	 */
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Time getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Time lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	@Override
	public String toString() {
		return "Book [bookIndex=" + bookIndex + ", id=" + id + ", image="  + ", title=" + title + ", author="
				+ author + ", category=" + category + ", price=" + price + ", lastUpdated=" + lastUpdated + "]";
	}
	
	
}
