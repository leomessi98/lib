package com.cg.BookStoreSpringWIthAngular.Controller;

import java.awt.Image;
import java.sql.Time;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import com.cg.BookStoreSpringWIthAngular.Beans.Book;
import com.cg.BookStoreSpringWIthAngular.Service.BookService;

@RestController
public class BookController {

	@Autowired
	BookService bookService;

	@RequestMapping(value = "/booklist",method = RequestMethod.GET,headers="Accept=application/json")
	public List<Book> getAllBooks(Model model) {
		
		return bookService.listBooks();
		
	}
	
	
	@RequestMapping(value = "/books/create/{id}/{title}/{author}/{category}/{price}/{lastUpdated}",
			headers="Accept=application/json", method = RequestMethod.POST)
	public List<Book> createBook(@PathVariable int id,@PathVariable String title,@PathVariable String author,@PathVariable String category,@PathVariable float price,@PathVariable Time lastUpdated ) {
		Book book = new Book();
		book.setId(id);
		//book.setImage(image);
	    book.setTitle(title);
		book.setAuthor(author);
		book.setCategory(category);
		book.setPrice(price);
		book.setLastUpdated(lastUpdated);
	
		return bookService.listBooks();
	}
	
	
	@RequestMapping(value = "/book/delete/{id}",
			headers="Accept=application/json",method = RequestMethod.DELETE)
	public List<Book> deleteBook(@PathVariable("id") int id) {
		System.out.println(id);
		bookService.deleteBook(id);
		return bookService.listBooks();
}
	@RequestMapping(value ="/book/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public List<Book> createBook(@RequestBody Book book) {
		
		System.out.println("hiiii");
		System.out.println(book);
		bookService.saveBook(book);
		return bookService.listBooks();
}
	@RequestMapping(value ="/book/search/{id}",headers="Accept=application/json",method = RequestMethod.GET)
	public Book searchBook(@PathVariable("id") int id) {
		System.out.println("In search");
		return bookService.getBook(id);
}
	@RequestMapping(value ="/book/update/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.PUT)
	public List<Book> updateBook(@RequestBody Book book) {
		
		System.out.println("Update");
		System.out.println(book);
		bookService.saveBook(book);
		return bookService.listBooks();
}
	}
